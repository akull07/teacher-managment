
package com.example.coursecrud.controller;

import com.example.coursecrud.model.Teacher;
import com.example.coursecrud.repository.TeacherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/teachers")
public class TeacherController {

    @Autowired
    private TeacherRepository repo;

    // POST /teachers → Add teacher
    @PostMapping
    public Teacher addTeacher(@RequestBody Teacher teacher) {
        return repo.save(teacher);
    }

    // GET /teachers → Get all teachers
    @GetMapping
    public List<Teacher> getAllTeachers() {
        return repo.findAll();
    }

    // PUT /teachers/{id} → Update teacher
    @PutMapping("/{id}")
    public Teacher updateTeacher(@PathVariable Long id, @RequestBody Teacher teacher) {
        teacher.setId(id);
        return repo.save(teacher);
    }

    // DELETE /teachers/{id} → Delete teacher
    @DeleteMapping("/{id}")
    public void deleteTeacher(@PathVariable Long id) {
        repo.deleteById(id);
    }
}
