import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Container, Nav, Navbar } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';

// Import components (we'll create these next)
import CourseList from './components/CourseList';
import AddCourse from './components/AddCourse';
import CourseDetails from './components/CourseDetails';

function App() {
  return (
    <Router>
      <div className="App">
        <Navbar bg="dark" variant="dark" expand="lg">
          <Container>
            <Navbar.Brand as={Link} to="/">Teacher CRUD</Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
              <Nav className="me-auto">
                <Nav.Link as={Link} to="/">All Teachers</Nav.Link>
                <Nav.Link as={Link} to="/add">Add Teacher</Nav.Link>
              </Nav>
            </Navbar.Collapse>
          </Container>
        </Navbar>

        <Container className="mt-4">
          <Routes>
            <Route path="/" element={<CourseList />} />
            <Route path="/add" element={<AddCourse />} />
            <Route path="/courses/:id" element={<CourseDetails />} />
            <Route path="/courses/edit/:id" element={<AddCourse />} />
          </Routes>
        </Container>
      </div>
    </Router>
  );
}

export default App;