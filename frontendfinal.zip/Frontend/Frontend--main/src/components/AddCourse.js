import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Form, Button, Card, Alert, Spinner, Row, Col } from 'react-bootstrap';
import TeacherService from '../services/TeacherService';

const AddCourse = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEditMode = !!id;

  const [loading, setLoading] = useState(false);
  const [loadingTeacher, setLoadingTeacher] = useState(isEditMode);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  const [teacher, setTeacher] = useState({
    name: '',
    subject: ''
  });

  // Fetch teacher data if edit mode
  useEffect(() => {
    if (isEditMode) {
      TeacherService.getTeacherById(id)
        .then(response => {
          setTeacher({
            name: response.data.name || '',
            subject: response.data.subject || ''
          });
        })
        .catch(err => {
          setError('Failed to load teacher');
          console.error(err);
        })
        .finally(() => {
          setLoadingTeacher(false);
        });
    }
  }, [id, isEditMode]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setTeacher(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const validateForm = () => {
    if (!teacher.name.trim()) {
      setError('Teacher name is required');
      return false;
    }
    if (!teacher.subject.trim()) {
      setError('Subject is required');
      return false;
    }
    return true;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!validateForm()) return;

    setLoading(true);

    const promise = isEditMode
      ? TeacherService.updateTeacher(id, teacher)
      : TeacherService.createTeacher(teacher);

    promise
      .then(() => {
        setSuccess(isEditMode
          ? 'Teacher updated successfully!'
          : 'Teacher added successfully!'
        );

        setTeacher({ name: '', subject: '' });

        setTimeout(() => {
          navigate('/');
        }, 1500);
      })
      .catch(err => {
        setError('Failed to save teacher');
        console.error(err);
      })
      .finally(() => {
        setLoading(false);
      });
  };

  if (loadingTeacher) {
    return (
      <div className="loading-spinner">
        <Spinner animation="border" />
        <span className="ms-2">Loading...</span>
      </div>
    );
  }

  return (
    <div className="form-container">
      <Card>
        <Card.Body>
          <Card.Title className="mb-4">
            {isEditMode ? 'Edit Teacher' : 'Add Teacher'}
          </Card.Title>

          {error && <Alert variant="danger">{error}</Alert>}
          {success && <Alert variant="success">{success}</Alert>}

          <Form onSubmit={handleSubmit}>
            <Row>
              <Col md={12}>
                <Form.Group className="mb-3">
                  <Form.Label>Teacher Name *</Form.Label>
                  <Form.Control
                    type="text"
                    name="name"
                    value={teacher.name}
                    onChange={handleChange}
                    placeholder="Enter teacher name"
                    required
                  />
                </Form.Group>
              </Col>
            </Row>

            <Form.Group className="mb-4">
              <Form.Label>Subject *</Form.Label>
              <Form.Control
                type="text"
                name="subject"
                value={teacher.subject}
                onChange={handleChange}
                placeholder="Enter subject"
                required
              />
            </Form.Group>

            <div className="d-flex justify-content-between">
              <Button variant="secondary" as={Link} to="/">
                Back
              </Button>

              <Button
                variant={isEditMode ? 'warning' : 'primary'}
                type="submit"
                disabled={loading}
              >
                {loading
                  ? <Spinner size="sm" animation="border" />
                  : isEditMode ? 'Update Teacher' : 'Add Teacher'}
              </Button>
            </div>
          </Form>
        </Card.Body>
      </Card>
    </div>
  );
};

export default AddCourse;
