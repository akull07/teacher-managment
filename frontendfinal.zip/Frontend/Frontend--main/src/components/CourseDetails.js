import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  Card, Button, Alert, Spinner,
  Row, Col, ListGroup, Modal
} from 'react-bootstrap';
import TeacherService from '../services/TeacherService.js';

const CourseDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [teacher, setTeacher] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const fetchTeacherDetails = useCallback(() => {
    setLoading(true);
    TeacherService.getTeacherById(id)
      .then(response => {
        setTeacher(response.data);
        setError(null);
      })
      .catch(err => {
        setError('Failed to fetch teacher details');
        console.error(err);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [id]);

  useEffect(() => {
    fetchTeacherDetails();
  }, [fetchTeacherDetails]);

  const handleDelete = () => {
    setDeleting(true);
    TeacherService.deleteTeacher(id)
      .then(() => {
        navigate('/', {
          state: { message: 'Teacher deleted successfully!' }
        });
      })
      .catch(err => {
        setError('Failed to delete teacher');
        setDeleting(false);
        setShowDeleteModal(false);
      });
  };

  if (loading) {
    return (
      <div className="loading-spinner">
        <Spinner animation="border" />
        <span className="ms-2">Loading teacher details...</span>
      </div>
    );
  }

  if (error && !teacher) {
    return (
      <Alert variant="danger">
        {error}
        <div className="mt-3">
          <Button as={Link} to="/" variant="secondary">
            Back to Teacher List
          </Button>
        </div>
      </Alert>
    );
  }

  if (!teacher) {
    return (
      <Alert variant="warning">
        Teacher not found!
        <div className="mt-3">
          <Button as={Link} to="/" variant="primary">
            Back to Teacher List
          </Button>
        </div>
      </Alert>
    );
  }

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <Button variant="outline-secondary" as={Link} to="/">
            ← Back
          </Button>
          <h2 className="d-inline-block ms-3">Teacher Details</h2>
        </div>

        <div>
          <Button
            variant="primary"
            as={Link}
            to={`/courses/edit/${id}`}
            className="me-2"
          >
            Edit Teacher
          </Button>
          <Button
            variant="danger"
            onClick={() => setShowDeleteModal(true)}
          >
            Delete
          </Button>
        </div>
      </div>

      {error && (
        <Alert variant="danger" onClose={() => setError(null)} dismissible>
          {error}
        </Alert>
      )}

      <Row>
        <Col md={8}>
          <Card className="mb-4">
            <Card.Body>
              <Card.Title>{teacher.name}</Card.Title>
              <Card.Subtitle className="text-muted mb-3">
                Subject: {teacher.subject}
              </Card.Subtitle>

              <Card className="bg-light">
                <Card.Body>
                  <h6 className="mb-3">Teacher Information</h6>
                  <ListGroup variant="flush">
                    <ListGroup.Item className="bg-light">
                      <strong>Teacher ID:</strong> {teacher.id}
                    </ListGroup.Item>
                    <ListGroup.Item className="bg-light">
                      <strong>Name:</strong> {teacher.name}
                    </ListGroup.Item>
                    <ListGroup.Item className="bg-light">
                      <strong>Subject:</strong> {teacher.subject}
                    </ListGroup.Item>
                  </ListGroup>
                </Card.Body>
              </Card>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4}>
          <Card>
            <Card.Header>
              <h5 className="mb-0">Quick Actions</h5>
            </Card.Header>
            <ListGroup variant="flush">
              <ListGroup.Item action as={Link} to={`/courses/edit/${id}`}>
                ✏️ Edit Teacher
              </ListGroup.Item>
              <ListGroup.Item
                action
                className="text-danger"
                onClick={() => setShowDeleteModal(true)}
              >
                Delete Teacher
              </ListGroup.Item>
              <ListGroup.Item action as={Link} to="/">
                 View All Teachers
              </ListGroup.Item>
              <ListGroup.Item action as={Link} to="/add">
                Add New Teacher
              </ListGroup.Item>
            </ListGroup>
          </Card>
        </Col>
      </Row>

      {/* Delete Modal */}
      <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Confirm Delete</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>Are you sure you want to delete this teacher?</p>
          <h5 className="text-danger">{teacher.name}</h5>
        </Modal.Body>
        <Modal.Footer>
          <Button
            variant="secondary"
            onClick={() => setShowDeleteModal(false)}
            disabled={deleting}
          >
            Cancel
          </Button>
          <Button
            variant="danger"
            onClick={handleDelete}
            disabled={deleting}
          >
            {deleting ? (
              <>
                <Spinner size="sm" animation="border" className="me-2" />
                Deleting...
              </>
            ) : (
              'Delete Teacher'
            )}
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default CourseDetails;
