import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Table, Button, Spinner, Alert, Card } from "react-bootstrap";
import TeacherService from "../services/TeacherService";

const CourseList = () => {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const navigate = useNavigate();

  useEffect(() => {
    fetchTeachers();
  }, []);

  const fetchTeachers = () => {
    setLoading(true);
    TeacherService.getAllTeachers()
      .then((res) => {
        setCourses(res.data);
        setError(null);
      })
      .catch(() => setError("Failed to fetch teachers"))
      .finally(() => setLoading(false));
  };

  const deleteTeacher = (id) => {
    if (window.confirm("Delete this teacher?")) {
      TeacherService.deleteTeacher(id)
        .then(() => {
          setCourses(courses.filter((t) => t.id !== id));
        })
        .catch(() => setError("Delete failed"));
    }
  };

  if (loading) {
    return (
      <div className="text-center mt-5">
        <Spinner animation="border" />
      </div>
    );
  }

  return (
    <Card>
      <Card.Body>
        <div className="d-flex justify-content-between mb-3">
          <h3>Teacher Management</h3>
          <Button as={Link} to="/add" variant="success">
            Add Teacher
          </Button>
        </div>

        {error && <Alert variant="danger">{error}</Alert>}

        {courses.length === 0 ? (
          <Alert variant="info">No teachers found</Alert>
        ) : (
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>#</th>
                <th>Teacher Name</th>
                <th>Subject</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {courses.map((teacher, index) => (
                <tr key={teacher.id}>
                  <td>{index + 1}</td>
                  <td>{teacher.name}</td>
                  <td>{teacher.subject}</td>
                  <td>
                    <Button
                      size="sm"
                      variant="info"
                      className="me-2"
                      onClick={() => navigate(`/courses/${teacher.id}`)}
                    >
                      View
                    </Button>
                    <Button
                      size="sm"
                      variant="warning"
                      className="me-2"
                      onClick={() => navigate(`/courses/edit/${teacher.id}`)}
                    >
                      Edit
                    </Button>
                    <Button
                      size="sm"
                      variant="danger"
                      onClick={() => deleteTeacher(teacher.id)}
                    >
                      Delete
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card.Body>
    </Card>
  );
};

export default CourseList;
