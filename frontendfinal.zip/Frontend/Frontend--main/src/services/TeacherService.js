import axios from "axios";

const API_URL = "/teachers";

class TeacherService {
  // Teacher methods
  getAllTeachers() {
    return axios.get(API_URL);
  }

  getTeacherById(id) {
    return axios.get(`${API_URL}/${id}`);
  }

  createTeacher(teacher) {
    console.log('Creating teacher:', teacher);
    return axios.post(API_URL, teacher)
      .then(response => {
        console.log('Teacher created successfully:', response);
        return response;
      })
      .catch(error => {
        console.error('Error creating teacher:', error);
        if (error.response) {
          console.error('Error response:', error.response.data);
          console.error('Error status:', error.response.status);
        } else if (error.request) {
          console.error('No response received:', error.request);
        } else {
          console.error('Request setup error:', error.message);
        }
        throw error;
      });
  }

  updateTeacher(id, teacher) {
    return axios.put(`${API_URL}/${id}`, teacher);
  }

  deleteTeacher(id) {
    return axios.delete(`${API_URL}/${id}`);
  }

  // Course methods (aliases for backward compatibility)
  getAllCourses() {
    return this.getAllTeachers();
  }

  getCourseById(id) {
    return this.getTeacherById(id);
  }

  createCourse(course) {
    return this.createTeacher(course);
  }

  updateCourse(id, course) {
    return this.updateTeacher(id, course);
  }

  deleteCourse(id) {
    return this.deleteTeacher(id);
  }
}

const teacherService = new TeacherService();
export default teacherService;
